// Brad Howard
// Project ACTBS

// Read File interface
// Ver 0.99

package travelpackage;

public interface ReadFile
{
   public void readFile();
}