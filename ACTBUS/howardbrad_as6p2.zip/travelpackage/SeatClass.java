// Brad Howard
// Project ACTBS

// SeatClass
// Ver 0.99

package travelpackage;

public enum SeatClass
{
   FIRST,
   BUSINESS,
   ECONOMY
}