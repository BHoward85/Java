// Brad Howard
// Project ACTBS

// Seaport
// Ver 0.99

package travelpackage;

public interface Port
{
   public String getCode();
}