// Brad Howard
// Project 3: Sort Merge Join

import java.util.*;
import java.io.*;

public class SortMergeJoin
{
   private ArrayList<String> dataSet1 = new ArrayList<String>();
   private ArrayList<String> dataSet2 = new ArrayList<String>();
   private Block[] blocks1;
   private Block[] blocks2;
   private Partition[] pars1;
   private Partition[] pars2;
   private int numberOfPart1;
   private int numberOfPart2;
   private Scanner input1;
   private Scanner input2;
   private PrintStream output1;
   private PrintStream output2;
   private File file1;
   private File file2;
   private int memorySize;
   private int blockSize;
   private Block[] memory;
   
   public SortMergeJoin(File a, File b, int sizeOfMemory, int sizeOfBlock)
   {
      file1 = a;
      file2 = b;
      memorySize = sizeOfMemory;
      blockSize = sizeOfBlock;
      memory = new Block[memorySize];
      
      try
      {
         input1 = new Scanner(file1);
         input2 = new Scanner(file2);
      }
      catch(IOException ioe)
      {
         System.out.println("Error");
         return;
      }
   }
   
   public void sort()
   {
      while(input1.hasNext())
      {
         dataSet1.add(input1.nextLine());
      }
      while(input2.hasNext())
      {
         dataSet2.add(input2.nextLine());
      }
      
      int numberOfBlocks1 = 1 + dataSet1.size() / blockSize;
      int numberOfBlocks2 = 1 + dataSet2.size() / blockSize;
      
      blocks1 = new Block[numberOfBlocks1];
      blocks2 = new Block[numberOfBlocks2];
      
      for(int index = 0, jdex = 0; index < blocks1.length; index++)
      {
         blocks1[index] = new Block(blockSize);
         blocks1[index].setBID(index);
         for(int bdex = 0; bdex < blockSize && jdex < dataSet1.size(); jdex++, bdex++)
         {
            blocks1[index].addRecord(dataSet1.get(jdex));
         }
         blocks1[index].sortRecords();
      }
      
      for(int index = 0, jdex = 0; index < blocks2.length; index++)
      {
         blocks2[index] = new Block(blockSize);
         blocks2[index].setBID(index);
         for(int bdex = 0; bdex < blockSize && jdex < dataSet2.size(); jdex++, bdex++)
         {
            blocks2[index].addRecord(dataSet2.get(jdex));
         }
         blocks2[index].sortRecords();
      }
      
      numberOfPart1 = 1 + numberOfBlocks1 / memorySize;
      numberOfPart2 = 1 + numberOfBlocks2 / memorySize;
      
      pars1 = new Partition[numberOfPart1];
      pars2 = new Partition[numberOfPart2];
      
      for(int index = 0; index < pars1.length; index++)
      {
         pars1[index] = new Partition(memorySize);
      }
      
      for(int index = 0; index < pars2.length; index++)
      {
         pars2[index] = new Partition(memorySize);
      }
   }
}