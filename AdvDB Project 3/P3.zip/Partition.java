// Brad Howard
// Project 3: Partition object

import java.util.*;

public class Partition
{
   private ArrayList<Block> group;
   private int partitionSize;
   
   public Partition(int n)
   {
      partitionSize = n;
      group = new ArrayList<Block>(partitionSize);
   }
   
   public void set(Block b)
   {
      group.add(b);
   }
   
   public Block get(int index)
   {
      return group.get(index);
   }
}