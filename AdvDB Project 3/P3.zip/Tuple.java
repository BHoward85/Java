// Brad Howard
// Project 3: Block object

import java.util.*;

public class Tuple implements Comparable<Tuple>
{
   private String[] data;   
   
   public void update(String[] input)
   {
      data = input;
   }
   
   public String[] get()
   {
      return data;
   }
   
   @Override
   public int compareTo(Tuple that)
   {
      return this.data[0].compareTo(that.get()[0]);
   }
}