Note, the way the output was sent to file has a mix of \n and \r, the output for the
input charts have \r at end of line instead of \n.